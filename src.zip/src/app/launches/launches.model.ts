export interface Launches {
    id:number;
    launch_name:string;
    launch_year:number;
    launch_date_utc:any;
    orbit:string;
    launch_success:boolean;
    thumbnailUrl:string;
}